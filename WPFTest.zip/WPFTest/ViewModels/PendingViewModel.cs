﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFTest.Models;

namespace WPFTest.ViewModels
{
    /// <summary>
    /// Handles the selection of a pending order from the datagrid
    /// </summary>
    public class PendingViewModel : ObservableObject
    {
        private PendingOrders _selectedPendingOrder;
        public PendingOrders SelectedPendingOrder
        {
            get { return _selectedPendingOrder; }
            set { OnPropertyChanged(ref _selectedPendingOrder, value); }
        }

        /// <summary>
        /// WPF friendly list for the collection of all pending orders
        /// </summary>
        public ObservableCollection<PendingOrders> PendingOrders { get; private set; }

        /// <summary>
        /// Constructor for Pending Orders
        /// </summary>
        //public PendingOrdersViewModel()
        //{

        //}

        /// <summary>
        /// Creates a new observablecollection every time pending orders is laoded
        /// </summary>
        /// <param name="contacts"></param>
        public void LoadPendingOrders(IEnumerable<PendingOrders> pendingOrders) // allows one to avoid doing a for each loop to add contacts manually
        {
            PendingOrders = new ObservableCollection<PendingOrders>(pendingOrders);
            OnPropertyChanged("PendingOrders");
        }
    }


}
