﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WPFTest.Utilities;

namespace WPFTest.ViewModels
{
    public class OrderViewModel : ObservableObject
    {
        private PendingViewModel _pendingOrdersVM;
        public PendingViewModel PendingOrdersVM
        {
            get { return _pendingOrdersVM; }
            set { OnPropertyChanged(ref _pendingOrdersVM, value); }
        }

        private object _currentView;
        public object CurrentView
        {
            get { return _currentView; }
            set { OnPropertyChanged(ref _currentView, value); }
        }

        public ICommand LoadPendingOrdersCommand { get; private set; }
        public ICommand LoadCarriersCommand { get; private set; }

        public OrderViewModel()
        {
            PendingOrdersVM = new PendingViewModel();

            LoadPendingOrdersCommand = new RelayCommand(LoadPendingOrders);
            LoadCarriersCommand = new RelayCommand(LoadCarriers);
        }

        private void LoadPendingOrders()
        {

        }

        private void LoadCarriers()
        {

        }

    }
}
